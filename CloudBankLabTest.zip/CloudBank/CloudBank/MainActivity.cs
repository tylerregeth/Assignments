﻿using Android.App;
using Android.Widget;
using Android.OS;

namespace CloudBank
{
    [Activity(Label = "CloudBank", MainLauncher = true)]
    public class MainActivity : Activity
    {
        EditText txtUsername;
        EditText txtPassword;
        Button btnLogin;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            // initialize controls
            txtUsername = FindViewById<EditText>(Resource.Id.txtUsername);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            Button btnLogin = FindViewById<Button>(Resource.Id.btnLogin);

            btnLogin.Click += BtnLogin_Click;
        }

        private void BtnLogin_Click(object sender, System.EventArgs e)
        {
            string username = txtUsername.Text.ToLower();
            string password = txtPassword.Text;

            // if statement to catch errors in username and password 
            if(username == "clouduser" && password == "318")
            {
                SetContentView(Resource.Layout.AccountsPage);
            }

            // call accounts page
            SetContentView(Resource.Layout.AccountsPage);

           
        }
    }
}

