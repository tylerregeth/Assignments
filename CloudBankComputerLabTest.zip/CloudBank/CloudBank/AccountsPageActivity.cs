﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{

    [Activity(Label = "AccountsPageActivity")]
    public class AccountsPageActivity : Activity
    {

        Button btnChecking;
        Button btnSavings;


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here

            Button btnChecking = FindViewById<Button>(Resource.Id.btnChecking);
            Button btnSavings = FindViewById<Button>(Resource.Id.btnSavings);

            btnChecking.Click += BtnChecking_Click;
            btnSavings.Click += BtnSavings_Click;

        }

        private void BtnSavings_Click(object sender, EventArgs e)
        {
            // call savings page
        }

        private void BtnChecking_Click(object sender, EventArgs e)
        {
            // call checking transactions page 
            SetContentView(Resource.Layout.TransactionsPage);
        }
    }
}